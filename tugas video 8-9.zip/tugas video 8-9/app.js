const validator = require('validator');
// console.log(validator.isEmail('raka@gmail.c'));
// console.log(validator.isMobilePhone('0812345678', 'id-ID'));
// console.log(validator.isNumeric('0782345678'));

// console.log(chalk.black.bgBlue('Hello World'));
const nama = 'raka';
const pesan = `lorem, ipsum dolor {bgRed sit amet} consectetur {bgGreen.italic.black adipisicing} elit. Nama saya: ${nama}`;
console.log(pesan);
